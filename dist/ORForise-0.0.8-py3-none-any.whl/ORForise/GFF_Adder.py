from importlib import import_module
import argparse
import collections
from datetime import date
import sys
try:
    from utils import sortORFs
except ImportError:
    from ORForise.utils import sortORFs



parser = argparse.ArgumentParser()
parser.add_argument('-dna', '--genome_DNA', required=True, help='Genome DNA file (.fa) which both annotations '
                                                                'are based on')
parser.add_argument('-rt', '--reference_tool', required=False,
                    help='Which tool format to use as reference? - Default: Standard Ensembl GFF format')
parser.add_argument('-ref', '--reference_annotation', required=True,
                    help='Which annotation to use as reference?')
parser.add_argument('-radd', '--additional_tool', required=True,
                    help='Which tool format to use as additional?')
parser.add_argument('-add', '--additional_annotation', required=True,
                    help='Which annotation file to add to reference annotation?')
parser.add_argument('-olap', action='store', dest='overlap', default=50, type=int, required=False,
                    help='maximum overlap between Gene and ORF')
parser.add_argument('-o', action='store', dest='output_file', required=True,
                    help='output filename')
args = parser.parse_args()


def gff_writer(reference_annotation, additional_annotation, output_file, new_ORFs, genome_gff):
    write_out = open(output_file, 'w')
    write_out.write("##gff-version\t3\n#\tGFF Adder\n#\tRun Date:" + str(date.today()) + '\n')
    write_out.write("##Original File: " + genome_gff.name + "\n##Additional Tool: " + additional_annotation + '\n')
    for pos, data in new_ORFs.items():
        pos_ = pos.split(',')
        start = pos_[0]
        stop = pos_[-1]
        strand = data[0]
        if len(data) == 3:  # Addition Tool ORFs have start and stop codons
            type = additional_annotation
            entry = (
                        reference_annotation + '\t' + type + '\tORF\t' + start + '\t' + stop + '\t.\t' + strand + '\t.\tID=Predicted_Additional_ORF' + '\n')
        else:
            type = 'original'
            entry = (
                        reference_annotation + '\t' + type + '\tORF\t' + start + '\t' + stop + '\t.\t' + strand + '\t.\tID=Original_Annotation' + '\n')
        write_out.write(entry)


def gff_adder(genome_DNA, reference_tool, reference_annotation, additional_tool, additional_annotation, overlap, output_file):  # Only works for single contig genome
    genome_Seq = ""
    with open(genome_DNA, 'r') as genome_fasta:
        for line in genome_fasta:
            line = line.replace("\n", "")
            if not line.startswith('>'):
                genome_Seq += str(line)
    ###########################################
    if not reference_tool:  # IF using Ensembl for comparison
        ref_genes = collections.OrderedDict()  # Order is important
        count = 0
        with open(reference_annotation, 'r') as genome_gff:
            for line in genome_gff:
                line = line.split('\t')
                try:
                    if "CDS" in line[2] and len(line) == 9:
                        start = int(line[3])
                        stop = int(line[4])
                        strand = line[6]
                        gene_details = [start,stop,strand]
                        ref_genes.update({count:gene_details})
                        count += 1
                except IndexError:
                    continue
    else:  # IF using a tool as reference
        try:
            reference_tool_ = import_module('Tools.' + reference_tool + '.' + reference_tool,
                                             package='my_current_pkg')
        except ModuleNotFoundError:
            try:
                reference_tool_ = import_module('ORForise.Tools.' + reference_tool + '.' + reference_tool,
                                             package='my_current_pkg')
            except ModuleNotFoundError:
                sys.exit("Tool not available")
        reference_tool_ = getattr(reference_tool_, reference_tool)
        ############ Reformatting tool output for ref_genes
        ref_genes_tmp = reference_tool_(reference_annotation, genome_Seq)
        ref_genes = collections.OrderedDict()
        for i, (pos, details) in enumerate(ref_genes_tmp.items()):
            pos = pos.split(',')
            ref_genes.update({i:[pos[0],pos[1],details[0]]})
    ################ Get Add'
    try:
        additional_tool_ = import_module('Tools.' + additional_tool + '.' + additional_tool,
                                        package='my_current_pkg')
    except ModuleNotFoundError:
        try:
            additional_tool_ = import_module('ORForise.Tools.' + additional_tool + '.' + additional_tool,
                                            package='my_current_pkg')
        except ModuleNotFoundError:
            sys.exit("Tool not available")
    additional_tool_ = getattr(additional_tool_, additional_tool)
    additional_orfs = additional_tool_(additional_annotation, genome_Seq)
    orfs_To_Remove = []

    for orf in additional_orfs.keys():
        o_Start = int(orf.split(',')[0])
        o_Stop = int(orf.split(',')[1])
        orf_Set = set(range(int(o_Start), int(o_Stop) + 1))
        for gene_num, gene_details in ref_genes.items():  # Loop through each gene to compare against predicted ORFs
            g_Start = int(gene_details[0])
            g_Stop = int(gene_details[1])
            gene_Set = set(range(int(g_Start), int(g_Stop) + 1))
            cov = len(orf_Set.intersection(gene_Set))
            if cov >= overlap:
                orfs_To_Remove.append(str(o_Start) + ',' + str(o_Stop))
            if g_Start > o_Stop:
                break
    for orf_Key in orfs_To_Remove:  # Remove ORFs from out of frame if ORF was correctly matched to another Gene
        if orf_Key in additional_orfs:
            del additional_orfs[orf_Key]
    #########################################################
    new_ORFs = {**ref_genes, **additional_orfs}
    #new_ORFs = sortORFs(new_ORFs)

    gff_writer(reference_tool, reference_annotation, additional_tool, additional_annotation, output_file)


if __name__ == "__main__":
    gff_adder(**vars(args))

    print("Complete")
